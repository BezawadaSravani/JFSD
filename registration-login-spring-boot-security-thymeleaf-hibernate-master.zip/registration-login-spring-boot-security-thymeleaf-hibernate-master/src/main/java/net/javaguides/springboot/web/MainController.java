package net.javaguides.springboot.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@GetMapping("/")
	public String home() {
		return "index";
	}
	
	@GetMapping("/contact")
	public String contact() {
		return "contact";
	}
	@GetMapping("/about")
	public String about() {
		return "about";
	}
	@GetMapping("/index")
	public String index() {
		return "index";
	}
	
	@GetMapping("/events")
	public String events() {
		return "events";
	}
	@GetMapping("/reverification")
	public String reverification() {
		return "reverification";
	}
	@GetMapping("/payment")
	public String payment() {
		return "payment";
	}
	
	@GetMapping("/booking")
	public String booking() {
		return "booking";
	}
	@GetMapping("/card")
	public String card() {
		return "card";
	}
	
}
